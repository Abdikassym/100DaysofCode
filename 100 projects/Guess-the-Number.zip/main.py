import random
from art import logo

lives = 0
answer = random.randint(1, 101)
game_over = False

def compare(guess, answer):
  global lives, game_over
  
  if guess > answer:
    print("Too high.")
    print("Guess again")
    lives -= 1
    print(f"You have {lives} attempts remaining to guess the number.")


  elif guess < answer:
    print("Too low.")
    print("Guess again.")
    lives -= 1
    print(f"You have {lives} attempts remaining to guess the number.")

  else:
    print(f"You got it! The answer was {answer}")
    game_over = True



# Game
print(logo)
print("Welcome to a Number Guessing Game!")
print("I am thinking of a number between 1 and 100.")

if input("Choose a difficulty. Type 'easy' or 'hard': ") == 'easy':
  lives = 10
else:
  lives = 5
print(f"You have {lives} attempts remaining to guess the number.")

while not game_over:
  if lives == 0:
    print("You've ran out of guesses, you lose.")
    game_over = True
  else:
    guess = int(input("Make a guess: "))
    compare(guess, answer)